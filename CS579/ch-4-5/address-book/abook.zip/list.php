<?php 
// connect to my sql
$host="tinman.cs.gsu.edu"; // Host name
$username="cms";	// Mysql username
$password="cms123";	// Mysql password
$db_name="conf";	// Database name
$tbl_name="contacts"; // Table name
	
// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");

// show all contact information
$sql="select * from $tbl_name order by lname";
$result = mysql_query($sql);
mysql_close();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<BODY background="http://tinman.cs.gsu.edu/~raj/gifs/bkg2.gif" bgcolor="#FFFFFF" text="#000000" link="#0000FF" vlink="#800080" alink="#FF0000">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<blockquote>
  <p>
  <h2>All  Contact Information</h2>
   <?php
   		if (mysql_num_rows($result)==0){
			echo "<h4>No data<h4>"; 
		} else {
   			while($row = mysql_fetch_assoc($result)) {
				$lname = $row['lname'];
  				$fname = $row['fname'];
				echo "<ul><li><h4><a href=\"detail.php?lname=$lname&fname=$fname\">$lname, $fname</a><h4></li></ul>";
			}
		}
		 
	?>
	
</blockquote>
</body>
</html>
